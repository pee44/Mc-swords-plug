
package me.thomas.customweapons;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.*;

import java.util.*;

public class WeaponListener implements Listener {

    private Map<UUID, Long> flameCD = new HashMap<>();
    private Map<UUID, Long> chainCD = new HashMap<>();
    private Map<UUID, Long> lifestealCD = new HashMap<>();
    private Map<UUID, Long> axeCD = new HashMap<>();
    private Map<UUID, Long> crossbowCD = new HashMap<>();
    private Map<UUID, Long> icebowCD = new HashMap<>();

    private Random random = new Random();

    private boolean cooldown(Player p, Map<UUID, Long> map, int seconds) {

        long now = System.currentTimeMillis();

        if (map.containsKey(p.getUniqueId())) {

            long last = map.get(p.getUniqueId());

            if ((now - last) / 1000 < seconds) {
                p.sendMessage(ChatColor.RED + "Ability on cooldown!");
                return true;
            }
        }

        map.put(p.getUniqueId(), now);
        return false;
    }

    @EventHandler
    public void zeus(EntityDamageByEntityEvent e) {

        if (!(e.getDamager() instanceof Player)) return;

        Player p = (Player) e.getDamager();
        ItemStack item = p.getInventory().getItemInMainHand();

        if (!item.hasItemMeta()) return;

        if (item.getItemMeta().getDisplayName().contains("Zeus")) {

            if (random.nextInt(100) < 20) {

                e.getEntity().getWorld().strikeLightning(e.getEntity().getLocation());
            }
        }
    }

    @EventHandler
    public void swordAbilities(PlayerInteractEvent e) {

        Player p = e.getPlayer();

        if (!p.isSneaking()) return;

        ItemStack item = p.getInventory().getItemInMainHand();

        if (!item.hasItemMeta()) return;

        String name = item.getItemMeta().getDisplayName();

        if (name.contains("Flame Sword")) {

            if (cooldown(p, flameCD, 60)) return;

            p.launchProjectile(Fireball.class);
        }

        if (name.contains("Chain Sword")) {

            if (cooldown(p, chainCD, 20)) return;

            for (Entity en : p.getNearbyEntities(10,10,10)) {

                if (en instanceof Player) {

                    en.teleport(p.getLocation());

                    Block b = en.getLocation().getBlock();
                    b.setType(Material.COBWEB);

                    ((LivingEntity) en).damage(2);
                    break;
                }
            }
        }

        if (name.contains("Life Stealer")) {

            if (cooldown(p, lifestealCD, 60)) return;

            p.addPotionEffect(new PotionEffect(
                    PotionEffectType.REGENERATION,
                    20*20,
                    1));
        }

        if (name.contains("Shockwave Axe")) {

            if (cooldown(p, axeCD, 30)) return;

            for (Entity en : p.getNearbyEntities(7,7,7)) {

                if (en instanceof LivingEntity && en != p) {

                    en.setVelocity(
                        en.getLocation().toVector()
                        .subtract(p.getLocation().toVector())
                        .normalize()
                        .multiply(1.5)
                    );

                    ((LivingEntity) en).damage(4);
                }
            }
        }
    }

    @EventHandler
    public void crossbowShoot(EntityShootBowEvent e) {

        if (!(e.getEntity() instanceof Player)) return;

        Player p = (Player) e.getEntity();

        ItemStack item = e.getBow();

        if (!item.hasItemMeta()) return;

        if (item.getItemMeta().getDisplayName().contains("Warden Crossbow")) {

            if (cooldown(p, crossbowCD, 60)) {
                e.setCancelled(true);
                return;
            }

            for (Entity en : p.getNearbyEntities(15,15,15)) {

                if (en instanceof LivingEntity && en != p) {

                    ((LivingEntity) en).damage(8);

                    ((LivingEntity) en).addPotionEffect(
                        new PotionEffect(PotionEffectType.BLINDNESS,100,1));

                    ((LivingEntity) en).addPotionEffect(
                        new PotionEffect(PotionEffectType.WEAKNESS,100,1));
                }
            }
        }
    }

    @EventHandler
    public void iceArrow(ProjectileHitEvent e) {

        if (!(e.getEntity().getShooter() instanceof Player)) return;

        Player p = (Player) e.getEntity().getShooter();

        ItemStack item = p.getInventory().getItemInMainHand();

        if (!item.hasItemMeta()) return;

        if (!item.getItemMeta().getDisplayName().contains("Ice Bow")) return;

        if (cooldown(p, icebowCD, 60)) return;

        Location loc = e.getEntity().getLocation();

        for (Block b : getNearbyBlocks(loc,3)) {

            if (b.getType() == Material.AIR)
                b.setType(Material.ICE);
        }

        for (Entity en : loc.getWorld().getNearbyEntities(loc,3,3,3)) {

            if (en instanceof LivingEntity && en != p) {

                ((LivingEntity) en).damage(6);
                en.setFreezeTicks(200);
            }
        }
    }

    private List<Block> getNearbyBlocks(Location loc, int radius) {

        List<Block> blocks = new ArrayList<>();

        for (int x=-radius;x<=radius;x++)
            for (int y=-radius;y<=radius;y++)
                for (int z=-radius;z<=radius;z++)
                    blocks.add(loc.clone().add(x,y,z).getBlock());

        return blocks;
    }
}
