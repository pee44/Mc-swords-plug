
package me.thomas.customweapons;

import org.bukkit.plugin.java.JavaPlugin;

public class CustomWeapons extends JavaPlugin {

    @Override
    public void onEnable() {

        WeaponManager manager = new WeaponManager();

        getServer().getPluginManager().registerEvents(
                new WeaponListener(),
                this
        );

        getCommand("weapon").setExecutor(manager);

        getLogger().info("CustomWeapons enabled!");
    }
}
