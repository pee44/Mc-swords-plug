
package me.thomas.customweapons;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class WeaponManager implements CommandExecutor {

    private ItemStack create(Material mat, String name) {

        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();

        meta.setDisplayName(name);
        meta.setLore(List.of(ChatColor.GRAY + "Custom Weapon"));

        item.setItemMeta(meta);
        return item;
    }

    // ALL swords are Netherite
    public ItemStack flame() { return create(Material.NETHERITE_SWORD, ChatColor.RED + "Flame Sword"); }
    public ItemStack zeus() { return create(Material.NETHERITE_SWORD, ChatColor.YELLOW + "Zeus Sword"); }
    public ItemStack chain() { return create(Material.NETHERITE_SWORD, ChatColor.AQUA + "Chain Sword"); }
    public ItemStack lifesteal() { return create(Material.NETHERITE_SWORD, ChatColor.DARK_RED + "Life Stealer Sword"); }

    public ItemStack axe() { return create(Material.NETHERITE_AXE, ChatColor.GOLD + "Shockwave Axe"); }
    public ItemStack crossbow() { return create(Material.CROSSBOW, ChatColor.DARK_AQUA + "Warden Crossbow"); }
    public ItemStack icebow() { return create(Material.BOW, ChatColor.BLUE + "Ice Bow"); }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {

        if (!(sender instanceof Player)) return true;

        Player p = (Player) sender;

        if (args.length == 0) return true;

        switch (args[0].toLowerCase()) {

            case "flame": p.getInventory().addItem(flame()); break;
            case "zeus": p.getInventory().addItem(zeus()); break;
            case "chain": p.getInventory().addItem(chain()); break;
            case "lifesteal": p.getInventory().addItem(lifesteal()); break;
            case "axe": p.getInventory().addItem(axe()); break;
            case "warden": p.getInventory().addItem(crossbow()); break;
            case "icebow": p.getInventory().addItem(icebow()); break;
        }

        return true;
    }
}
